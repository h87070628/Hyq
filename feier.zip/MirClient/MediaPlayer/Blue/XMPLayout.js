// Gray
var g_PlayerContainerLeft = 5 ;
var g_PlayerContainerTop = 54 ;
var g_PlayerContainerWidthOffset = 10 ;
var g_PlayerContainerHeightOffset = 96 ;

var g_SearchEditLeftOffset =151;
var g_SearchEditTop = 31;
var g_SearchEditWidth = 116 ;
var g_SearchEditHeight = 16 ;

var g_SearchEditTipColor=0x5496cc;
var g_SearchEditTextColor=0x5496cc;

var g_InsetTabStartOffset = 221;
var g_SearchCloseOffset = 68 ;
var g_TabDistance = 0 ;
var g_MovieHallCloseOffset = 88 ;
var g_MoviehallIDOffset = 36 ;

